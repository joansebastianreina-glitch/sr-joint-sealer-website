# SR Joint Sealer – Caulker
Static website ready for GitHub Pages.

Files: index.html, style.css, script.js, CNAME.
Custom domain: srjointsealer-caulker.com.au
